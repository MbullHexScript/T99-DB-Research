$ErrorActionPreference = "Stop"

$source = $PSScriptRoot
$project = "D:\Games-kuyhAa\T99-Research\tools\pes_face_manager"
$engine = Join-Path $source "face_engine.py"
$gui = Join-Path $source "main.py"

if (!(Test-Path -LiteralPath $engine) -or !(Test-Path -LiteralPath $gui)) {
    throw "Paket tidak lengkap. Ekstrak ZIP terlebih dahulu."
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (!$python) { throw "Python tidak ditemukan. Pastikan Python tersedia di PATH." }

& python -c "import PySide6; print('PySide6 tersedia')"
if ($LASTEXITCODE -ne 0) { throw "PySide6 belum tersedia. Jalankan python -m pip install PySide6" }

& python -m py_compile $gui $engine
if ($LASTEXITCODE -ne 0) { throw "Kode tidak lolos pemeriksaan sintaks." }

if (!(Test-Path -LiteralPath $project)) {
    New-Item -ItemType Directory -Force -Path $project | Out-Null
}

$backupDir = Join-Path $project "backup"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$stamp = (Get-Date).ToString('yyyyMMdd-HHmmss') + '-' + ([guid]::NewGuid().ToString('N').Substring(0,6))

foreach ($filename in @('main.py', 'face_engine.py')) {
    $dest = Join-Path $project $filename
    if (Test-Path -LiteralPath $dest) {
        Copy-Item -LiteralPath $dest -Destination (Join-Path $backupDir "$filename.$stamp.bak") -ErrorAction Stop
    }
}

Copy-Item -LiteralPath $gui -Destination (Join-Path $project 'main.py') -Force -ErrorAction Stop
Copy-Item -LiteralPath $engine -Destination (Join-Path $project 'face_engine.py') -Force -ErrorAction Stop

$launcher = Join-Path $project 'START_PES_FACE_MANAGER.cmd'
@'
@echo off
cd /d "%~dp0"
python main.py
if errorlevel 1 pause
'@ | Set-Content -LiteralPath $launcher -Encoding Ascii

Write-Host "=== PES FACE MANAGER v1.0 ===" -ForegroundColor Cyan
Write-Host "Installed: $project"
Write-Host "Previous files (if any) backed up: $backupDir"
Write-Host "Launcher: $launcher"
Write-Host "Live face folders: NOT MODIFIED"
Write-Host "Sider configuration: NOT MODIFIED"

& python (Join-Path $project 'main.py')
