"""PES Face Manager v1.0 — Windows GUI for safe LiveCPK face updates."""
from __future__ import annotations

import sys
from pathlib import Path
from PySide6.QtCore import QAbstractTableModel, QObject, Qt, QSortFilterProxyModel, QThread, QLockFile, Signal, Slot
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QFileDialog, QFrame, QHBoxLayout,
    QHeaderView, QInputDialog, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QProgressBar, QPushButton, QTableView, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget, QAbstractItemView
)
import face_engine as eng


def pretty(n: int) -> str:
    return f"{n / 1048576:,.2f} MB".replace(",", " ")


class FaceTableModel(QAbstractTableModel):
    headings = ["Player ID", "Nama Pemain", "Status"]

    def __init__(self):
        super().__init__()
        self.data_rows = []

    def set_rows(self, rows):
        self.beginResetModel()
        self.data_rows = rows
        self.endResetModel()

    def rowCount(self, parent=None):
        return len(self.data_rows)

    def columnCount(self, parent=None):
        return 3

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.headings[section]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.data_rows):
            return None
        pid, name, status = self.data_rows[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return [str(pid), name, status][index.column()]
        if role == Qt.ItemDataRole.UserRole:
            return f"{pid} {name}".casefold()
        if role == Qt.ItemDataRole.ForegroundRole and index.column() == 2:
            return QColor("#61C39D") if status == "T99 dikenal" else QColor("#E6B66B")
        if role == Qt.ItemDataRole.TextAlignmentRole and index.column() == 0:
            return Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
        return None


class FaceFilter(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.query = ""

    def set_query(self, query):
        self.query = query.casefold().strip()
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row, parent):
        if not self.query:
            return True
        data = self.sourceModel().data(self.sourceModel().index(source_row, 0), Qt.ItemDataRole.UserRole)
        return self.query in (data or "")

    def lessThan(self, left, right):
        if left.column() == 0 and right.column() == 0:
            return int(self.sourceModel().data(left)) < int(self.sourceModel().data(right))
        return str(self.sourceModel().data(left)).casefold() < str(self.sourceModel().data(right)).casefold()


class FileDropTable(QTableView):
    received = Signal(object)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.DropOnly)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.received.emit(paths)
            event.acceptProposedAction()
        else:
            event.ignore()


class DropZone(QFrame):
    received = Signal(object)

    def __init__(self):
        super().__init__()
        self.setObjectName("dropZone")
        self.setAcceptDrops(True)
        layout = QVBoxLayout(self)
        a = QLabel("Tarik folder face ke sini — satu ID atau satu folder berisi banyak ID")
        a.setAlignment(Qt.AlignmentFlag.AlignCenter)
        b = QLabel("Paket ZIP/RAR/7Z perlu diekstrak dulu. File sumber tidak disentuh pada mode Copy.")
        b.setObjectName("hint")
        b.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(a)
        layout.addWidget(b)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.received.emit(paths)
            event.acceptProposedAction()
        else:
            event.ignore()


class ScanWorker(QObject):
    done = Signal(object)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, paths, library):
        super().__init__()
        self.paths = paths
        self.library = library

    @Slot()
    def run(self):
        try:
            self.done.emit(eng.plan_import(self.paths, self.library))
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()


class ApplyWorker(QObject):
    progress = Signal(int, int, str)
    done = Signal(object)
    finished = Signal()

    def __init__(self, faces, library, move_staging):
        super().__init__()
        self.faces, self.library, self.move_staging = faces, library, move_staging

    @Slot()
    def run(self):
        outcomes = []
        for i, face in enumerate(self.faces, 1):
            self.progress.emit(i, len(self.faces), str(face.player_id))
            try:
                result = eng.apply_one(face, self.library, move_staging=self.move_staging)
                outcomes.append(result)
                if result.status == "WARNING":
                    break
            except Exception as exc:
                outcomes.append(eng.OperationResult(face.player_id, "FAILED", str(exc)))
                if eng.pending_transactions(self.library):
                    break
        self.done.emit(outcomes)
        self.finished.emit()


class PreviewDialog(QDialog):
    def __init__(self, plans, names, library):
        super().__init__()
        self.plans = plans
        self.library = library
        self.selected = []
        self.move_from_staging = False
        self.setWindowTitle("Pratinjau Update Face")
        self.resize(870, 520)
        outer = QVBoxLayout(self)
        valid = [x for x in plans if x.kind != "INVALID"]
        replacements = sum(x.kind == "REPLACE" for x in valid)
        summary = QLabel(
            f"{len(plans)} diperiksa   •   {len(valid)} valid   •   "
            f"{replacements} replace   •   {len(valid)-replacements} baru   •   "
            f"{len(plans)-len(valid)} ditahan"
        )
        summary.setObjectName("summary")
        outer.addWidget(summary)
        self.table = QTableWidget(len(plans), 6)
        self.table.setHorizontalHeaderLabels(["Pilih", "Player ID", "Nama", "Tindakan", "Lama", "Baru"])
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for col in (0, 1, 3, 4, 5):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        for row, face in enumerate(plans):
            box = QTableWidgetItem("")
            box.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            box.setCheckState(Qt.CheckState.Checked if face.kind != "INVALID" else Qt.CheckState.Unchecked)
            if face.kind == "INVALID":
                box.setFlags(Qt.ItemFlag.NoItemFlags)
            self.table.setItem(row, 0, box)
            columns = [str(face.player_id), names.get(face.player_id, "Tidak ada di database T99"),
                       face.kind if not face.reason else "DITAHAN", pretty(face.old_size), pretty(face.size)]
            for col, text in enumerate(columns, 1):
                cell = QTableWidgetItem(text)
                if face.reason:
                    cell.setToolTip(face.reason)
                self.table.setItem(row, col, cell)
        outer.addWidget(self.table)
        selector = QHBoxLayout()
        all_button = QPushButton("Pilih semua valid")
        all_button.clicked.connect(lambda: self.toggle_all(True))
        none_button = QPushButton("Kosongkan")
        none_button.clicked.connect(lambda: self.toggle_all(False))
        selector.addWidget(all_button)
        selector.addWidget(none_button)
        selector.addStretch()
        outer.addLayout(selector)

        self.move_box = QCheckBox("Mode Move cepat untuk staging di samping folder real (sumber akan dipindahkan)")
        self.move_box.setChecked(False)
        outer.addWidget(self.move_box)
        warning = QLabel(
            "Mode Copy: sumber tetap ada, membutuhkan ruang sementara. "
            "Mode Move: hanya folder staging satu volume; hasil terpasang menggantikan sumber. "
            "Setiap ID diverifikasi SHA256 sebelum backup lama dihapus."
        )
        warning.setObjectName("hint")
        warning.setWordWrap(True)
        outer.addWidget(warning)

        actions = QHBoxLayout()
        cancel = QPushButton("Batal")
        cancel.clicked.connect(self.reject)
        submit = QPushButton("Lanjutkan Update")
        submit.setObjectName("primary")
        submit.clicked.connect(self.confirm)
        actions.addStretch()
        actions.addWidget(cancel)
        actions.addWidget(submit)
        outer.addLayout(actions)

    def toggle_all(self, checked):
        for row, face in enumerate(self.plans):
            if face.kind != "INVALID":
                self.table.item(row, 0).setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)

    def confirm(self):
        chosen = [face for row, face in enumerate(self.plans)
                  if face.kind != "INVALID" and self.table.item(row, 0).checkState() == Qt.CheckState.Checked]
        if not chosen:
            QMessageBox.warning(self, "Tidak ada pilihan", "Pilih minimal satu paket face yang valid.")
            return
        self.move_from_staging = self.move_box.isChecked()
        if self.move_from_staging:
            bad = [str(face.player_id) for face in chosen if face.source.parent.resolve() != self.library.parent.resolve()]
            if bad:
                QMessageBox.warning(self, "Move tidak tersedia", "Mode Move hanya untuk folder ID langsung di sisi real. ID lain: " + ", ".join(bad[:8]))
                return
        replacements = sum(x.kind == "REPLACE" for x in chosen)
        message = (
            f"Proses {len(chosen)} face ({replacements} replace, "
            f"{len(chosen)-replacements} baru)?\n\n"
            f"Library: {self.library}\n"
            f"Metode sumber: {'MOVE' if self.move_from_staging else 'COPY'}\n\n"
            "Tutup PES 2021 dan Sider dahulu. Backup lama dibersihkan hanya setelah SHA256 cocok. "
            "Batch diproses per ID; yang sudah berhasil tidak dibatalkan jika ID berikutnya gagal."
        )
        if QMessageBox.question(self, "Konfirmasi pemrosesan", message,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        if len(chosen) >= 50:
            word, ok = QInputDialog.getText(self, "Konfirmasi batch besar", f"Akan memproses {len(chosen)} face. Ketik GANTI untuk melanjutkan:")
            if not ok or word.strip() != "GANTI":
                return
        self.selected = chosen
        self.accept()


class FaceManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PES Face Manager • v1.0")
        self.resize(1180, 790)
        self.library = eng.LIBRARY
        self.names = {}
        self._thread = None
        self._worker = None
        self._busy = False
        self.setup_ui()
        self.refresh()

    def setup_ui(self):
        c = QWidget()
        self.setCentralWidget(c)
        outer = QVBoxLayout(c)
        outer.setContentsMargins(28, 24, 28, 20)
        outer.setSpacing(12)
        heading = QLabel("PES Face Manager")
        heading.setObjectName("title")
        outer.addWidget(heading)
        sub = QLabel("LiveCPK face library • T99 Patch v10 • Smart Replace & Batch Import")
        sub.setObjectName("hint")
        outer.addWidget(sub)

        line = QHBoxLayout()
        self.path_label = QLabel(str(self.library))
        self.path_label.setObjectName("path")
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        line.addWidget(self.path_label, 1)
        folder = QPushButton("Pilih Library")
        folder.clicked.connect(self.choose_library)
        line.addWidget(folder)
        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.clicked.connect(self.refresh)
        line.addWidget(self.refresh_button)
        outer.addLayout(line)

        self.stats = QLabel("Memuat library...")
        self.stats.setObjectName("summary")
        outer.addWidget(self.stats)

        self.sider_label = QLabel("")
        self.sider_label.setObjectName("hint")
        self.sider_label.setWordWrap(True)
        priority = QHBoxLayout()
        priority.addWidget(self.sider_label, 1)
        self.priority_button = QPushButton("Prioritaskan Faces di Sider")
        self.priority_button.clicked.connect(self.repair_priority)
        priority.addWidget(self.priority_button)
        outer.addLayout(priority)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Cari Player ID atau nama pemain...")
        self.search.textChanged.connect(self.filter_rows)
        outer.addWidget(self.search)

        self.model = FaceTableModel()
        self.proxy = FaceFilter()
        self.proxy.setSourceModel(self.model)
        self.table = FileDropTable()
        self.table.setModel(self.proxy)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.table.verticalHeader().hide()
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(2, 210)
        self.table.received.connect(self.scan)
        outer.addWidget(self.table, 1)

        self.zone = DropZone()
        self.zone.received.connect(self.scan)
        outer.addWidget(self.zone)
        row = QHBoxLayout()
        self.import_button = QPushButton("Pilih Folder untuk Import")
        self.import_button.setObjectName("primary")
        self.import_button.clicked.connect(self.pick_source)
        row.addWidget(self.import_button)
        row.addStretch()
        self.progress = QProgressBar()
        self.progress.setMinimum(0)
        self.progress.setMaximum(100)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        row.addWidget(self.progress, 1)
        outer.addLayout(row)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(95)
        outer.addWidget(self.log)
        footer = QLabel("v1.0 • Transaksi per ID • SHA256 • Pemulihan setelah interupsi • Offline")
        footer.setObjectName("hint")
        outer.addWidget(footer)
        self.setStyleSheet("""
            QMainWindow, QWidget, QDialog {background:#11151C;color:#ECF0F5;font:13px 'Segoe UI';}
            QLabel#title {font-size:27px;font-weight:700;}
            QLabel#hint {color:#96A1B0;}
            QLabel#path {background:#1D2530;padding:12px;border:1px solid #303A48;border-radius:8px;}
            QLabel#summary {background:#1D2530;padding:15px;border-radius:9px;font-weight:600;}
            QLineEdit {background:#1D2530;border:1px solid #364252;border-radius:7px;padding:10px;color:#F5F8FF;}
            QPushButton {background:#2A3444;border:1px solid #3B4759;border-radius:7px;padding:10px 15px;font-weight:600;}
            QPushButton:hover {background:#36495F;}
            QPushButton#primary {background:#456BA5;border-color:#567FBC;}
            QPushButton#primary:hover {background:#527DBB;}
            QPushButton:disabled {color:#6B7481;background:#1C232E;}
            QTableView, QTableWidget, QTextEdit {background:#171E28;alternate-background-color:#1D2632;
                border:1px solid #303B49;gridline-color:transparent;selection-background-color:#344C6A;}
            QHeaderView::section {background:#273241;color:#B9C8D9;border:0;padding:10px;font-weight:600;}
            QFrame#dropZone {background:#171F2A;border:1px dashed #536478;border-radius:9px;padding:12px;}
            QProgressBar {background:#202937;border-radius:6px;border:1px solid #3B4759;text-align:center;}
            QProgressBar::chunk {background:#4C86C6;border-radius:5px;}
            QCheckBox {padding:5px;}
        """)

    def log_line(self, message):
        self.log.append(message)

    def refresh(self):
        try:
            self.names = eng.load_names()
        except Exception as exc:
            self.names = {}
            self.log_line(f"Database T99 tidak terbaca: {exc}")
        try:
            known, aliases = eng.library_records(self.library)
            rows = [(pid, self.names.get(pid, "Tidak ada di database T99"),
                     "T99 dikenal" if pid in self.names else "ID tidak dikenal")
                    for pid in sorted(known)]
            self.model.set_rows(rows)
            matches = sum(pid in self.names for pid in known)
            self.stats.setText(
                f"{len(known):,} face terpasang    •    {matches:,} ID T99 dikenal    •    "
                f"{len(known)-matches:,} ID tidak dikenal    •    {len(aliases)} ID folder ambigu"
            )
        except Exception as exc:
            self.model.set_rows([])
            self.stats.setText("Gagal membaca library: " + str(exc))
        self.path_label.setText(str(self.library))
        status, _ = eng.sider_root_status(eng.SIDER_INI)
        self.sider_label.setText(status)
        self.priority_button.setEnabled("PERINGATAN" in status and not self._busy)
        pending = eng.pending_transactions(self.library) if self.library.is_dir() else []
        if pending:
            self.log_line(f"PERHATIAN: ada {len(pending)} transaksi tertunda.")
            self.ask_recovery()

    def filter_rows(self, query):
        self.proxy.set_query(query)

    def choose_library(self):
        folder = QFileDialog.getExistingDirectory(self, "Pilih folder real", str(self.library))
        if not folder:
            return
        new = Path(folder)
        if new.name.lower() != "real":
            QMessageBox.warning(self, "Library tidak valid", "Pilih folder .../asset/model/character/face/real")
            return
        if self._busy:
            return
        self.library = new
        self.refresh()

    def ask_recovery(self):
        pending = eng.pending_transactions(self.library)
        if not pending:
            return
        ans = QMessageBox.question(self, "Transaksi tertunda",
            f"Ditemukan {len(pending)} transaksi yang mungkin terputus.\n"
            "Klik Yes untuk memulihkan/merapikan. Import dikunci sampai semua transaksi selesai.\n"
            "Data pemulihan yang bermasalah tidak akan dihapus otomatis.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if ans == QMessageBox.StandardButton.Yes:
            for message in eng.recover_transactions(self.library):
                self.log_line(message)
            if eng.pending_transactions(self.library):
                QMessageBox.warning(self, "Perlu pemeriksaan manual",
                    "Masih ada transaksi tertunda. Buka folder .pfm-transactions di samping real dan periksa jurnalnya.")
            else:
                self.refresh()

    def pick_source(self):
        folder = QFileDialog.getExistingDirectory(self, "Pilih folder ID atau induk batch", str(self.library.parent))
        if folder:
            self.scan([Path(folder)])

    def set_busy(self, busy):
        self._busy = busy
        self.import_button.setDisabled(busy)
        self.refresh_button.setDisabled(busy)
        self.priority_button.setDisabled(busy)

    def run_thread(self, worker, completed):
        self._thread = QThread(self)
        self._worker = worker
        worker.moveToThread(self._thread)
        self._thread.started.connect(worker.run)
        worker.finished.connect(self._thread.quit)
        worker.finished.connect(worker.deleteLater)
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.finished.connect(self.worker_finished)
        worker.done.connect(completed)
        if isinstance(worker, ScanWorker):
            worker.failed.connect(self.thread_error)
        if isinstance(worker, ApplyWorker):
            worker.progress.connect(self.update_progress)
        self._thread.start()

    def worker_finished(self):
        self._thread = None
        self._worker = None
        self.set_busy(False)

    def thread_error(self, message):
        QMessageBox.critical(self, "Operasi gagal", message)
        self.log_line("Gagal: " + message)

    def scan(self, paths):
        if self._busy:
            return
        if eng.pending_transactions(self.library):
            self.ask_recovery()
            return
        self.set_busy(True)
        self.log_line("Memeriksa paket face...")
        self.run_thread(ScanWorker(list(paths), self.library), self.show_preview)

    def show_preview(self, plans):
        self.set_busy(False)
        if not plans:
            QMessageBox.warning(self, "Folder tidak cocok", "Tidak ditemukan folder Player ID numerik. Ekstrak paket terlebih dahulu.")
            return
        dialog = PreviewDialog(plans, self.names, self.library)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.log_line("Preview dibatalkan.")
            return
        self.set_busy(True)
        self.progress.setValue(0)
        self.log_line(f"Memulai update {len(dialog.selected)} face...")
        self.run_thread(ApplyWorker(dialog.selected, self.library, dialog.move_from_staging), self.apply_done)

    def update_progress(self, index, total, player_id):
        self.progress.setValue(round(100 * (index - 1) / max(1, total)))
        self.progress.setFormat(f"{index}/{total} • ID {player_id}")

    def apply_done(self, outcomes):
        success = sum(x.status in ("REPLACED", "NEW") for x in outcomes)
        failed = sum(x.status == "FAILED" for x in outcomes)
        warnings = sum(x.status == "WARNING" for x in outcomes)
        for item in outcomes:
            self.log_line(f"[{item.status}] ID {item.player_id}: {item.message}")
        self.progress.setValue(100 if not failed and not warnings else self.progress.value())
        QMessageBox.information(self, "Hasil update",
            f"Berhasil: {success}\nGagal: {failed}\nPeringatan: {warnings}\n\n"
            "Lihat log di bawah untuk rincian. Bila ada kegagalan, face lain yang berhasil tetap terpasang.")
        self.refresh()

    def repair_priority(self):
        if self._busy:
            return
        result = QMessageBox.question(self, "Perbaiki urutan Sider",
            "T99-Facepack berada di atas Faces, sehingga beberapa face yang diperbarui mungkin tidak terlihat di game.\n\n"
            "Pindahkan baris Faces sebelum T99-Facepack dalam sider.ini?\n"
            "Backup sider.ini dibuat dahulu. Pastikan PES dan Sider ditutup.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if result == QMessageBox.StandardButton.Yes:
            try:
                response = eng.prioritize_faces(eng.SIDER_INI)
                QMessageBox.information(self, "Sider", response)
                self.refresh()
            except Exception as exc:
                QMessageBox.critical(self, "Sider gagal diperbarui", str(exc))

    def closeEvent(self, event):
        if self._busy:
            QMessageBox.warning(self, "Proses berjalan", "Proses file masih berjalan. Jangan tutup aplikasi sebelum selesai.")
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PES Face Manager")
    lock = QLockFile(str(Path(__file__).resolve().with_name(".pes_face_manager.lock")))
    if not lock.tryLock(0):
        QMessageBox.warning(None, "PES Face Manager sudah terbuka",
                            "Tutup instance PES Face Manager lainnya dahulu.")
        return 1
    window = FaceManager()
    window.show()
    result = app.exec()
    lock.unlock()
    return result


if __name__ == "__main__":
    sys.exit(main())
