"""PES 2021 Face Manager engine. Offline, file-system only, Python 3.10+."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import uuid
import zlib

RESEARCH = Path(r"D:\Games-kuyhAa\T99-Research")
GAME = Path(r"D:\Games-kuyhAa\eFootball PES 2021")
LIBRARY = GAME / "sider/livecpk/Faces/asset/model/character/face/real"
SIDER_INI = GAME / "sider/sider.ini"
PLAYER_BIN = RESEARCH / "analysis/extracted-t99/liveupd/common/etc/pesdb/Player.bin"
FACE_REL = Path("Asset/model/character/face/real")
REQUIRED = (Path("#Win/face.fpk"), Path("#Win/face.fpkd"))


@dataclass(frozen=True)
class FaceCandidate:
    player_id: int
    source: Path
    target: Path
    kind: str  # REPLACE | NEW | INVALID
    size: int
    old_size: int
    count: int
    reason: str = ""


@dataclass(frozen=True)
class OperationResult:
    player_id: int
    status: str
    message: str


def is_link(path: Path) -> bool:
    # On Windows, a directory junction is a reparse point, not always a symlink.
    try:
        info = path.lstat()
        return path.is_symlink() or bool(
            getattr(info, "st_file_attributes", 0) & 0x400
        )
    except FileNotFoundError:
        return False


def is_within(path: Path, parent: Path) -> bool:
    try:
        return path.resolve().is_relative_to(parent.resolve())
    except (ValueError, OSError):
        return False


def walk_files(folder: Path):
    if is_link(folder):
        raise ValueError(f"Folder link/junction tidak didukung: {folder}")
    for root, dirs, files in os.walk(folder, followlinks=False):
        base = Path(root)
        for name in dirs + files:
            if is_link(base / name):
                raise ValueError(f"Link/junction tidak didukung: {base / name}")
        for name in files:
            item = base / name
            if not item.is_file():
                raise ValueError(f"Bukan file biasa: {item}")
            yield item


def folder_details(folder: Path) -> tuple[int, int]:
    total, count = 0, 0
    for item in walk_files(folder):
        size = item.stat().st_size
        if size == 0:
            raise ValueError(f"File kosong: {item.relative_to(folder)}")
        total += size
        count += 1
    for req in REQUIRED:
        item = folder / req
        if not item.is_file() or item.stat().st_size == 0:
            raise ValueError(f"File wajib hilang/kosong: {req}")
    return total, count


def manifest(folder: Path) -> dict[str, list]:
    """Stable per-file SHA256 including relative path, size and digest."""
    results = {}
    for item in walk_files(folder):
        h = hashlib.sha256()
        with item.open("rb") as fp:
            for chunk in iter(lambda: fp.read(1024 * 1024), b""):
                h.update(chunk)
        results[item.relative_to(folder).as_posix()] = [item.stat().st_size, h.hexdigest()]
    return results


def load_names(path: Path = PLAYER_BIN) -> dict[int, str]:
    if not path.is_file():
        return {}
    data = path.read_bytes()
    if len(data) < 16 or data[3:8] != b"WESYS":
        raise ValueError("Player.bin bukan WESYS")
    compressed_len, uncompressed_len = struct.unpack_from("<II", data, 8)
    if len(data) - 16 != compressed_len:
        raise ValueError("Ukuran WESYS tidak sesuai")
    obj = zlib.decompressobj()
    raw = obj.decompress(data[16:]) + obj.flush()
    if not obj.eof or obj.unused_data or obj.unconsumed_tail or len(raw) != uncompressed_len:
        raise ValueError("Data WESYS tidak lengkap")
    if len(raw) % 312:
        raise ValueError("Ukuran record Player.bin tidak sesuai")
    names = {}
    for i in range(0, len(raw), 312):
        player_id = struct.unpack_from("<I", raw, i + 8)[0]
        name = raw[i + 251:i + 312].split(b"\0", 1)[0].decode("utf-8", "strict")
        if player_id in names:
            raise ValueError(f"Player ID duplikat: {player_id}")
        names[player_id] = name
    return names


def library_records(library: Path) -> tuple[dict[int, Path], dict[int, list[Path]]]:
    if not library.is_dir() or is_link(library):
        raise ValueError(f"Library tidak valid: {library}")
    records: dict[int, list[Path]] = {}
    for child in library.iterdir():
        if child.is_dir() and child.name.isdecimal():
            records.setdefault(int(child.name), []).append(child)
    return ({i: entries[0] for i, entries in records.items() if len(entries) == 1},
            {i: entries for i, entries in records.items() if len(entries) > 1})


def source_folders(paths: list[Path]) -> list[Path]:
    """Accept one ID, parent of IDs, or extracted LiveCPK root."""
    found = []
    for original in paths:
        p = Path(original)
        if not p.is_dir() or is_link(p):
            continue
        if p.name.isdecimal():
            found.append(p)
            continue
        # Local parent first, e.g. staging face/ with real/ alongside IDs.
        direct = [x for x in p.iterdir() if x.is_dir() and x.name.isdecimal()]
        if direct:
            found.extend(direct)
            continue
        for candidate in (p / FACE_REL, p / "asset/model/character/face/real"):
            if candidate.is_dir():
                found.extend(x for x in candidate.iterdir()
                             if x.is_dir() and x.name.isdecimal())
                break
    return found


def plan_import(paths: list[Path], library: Path) -> list[FaceCandidate]:
    known, aliases = library_records(library)
    seen = set()
    result = []
    for source in source_folders(paths):
        pid = int(source.name)
        old = known.get(pid)
        target = old if old else library / str(pid)
        kind = "REPLACE" if old else "NEW"
        reason = ""
        size = count = old_size = 0
        if pid in seen:
            reason = "ID sama muncul lebih dari sekali dalam sumber"
        elif pid in aliases:
            reason = "Ada lebih dari satu folder ID ini di library"
        elif is_within(source, library):
            reason = "Sumber berada di dalam library aktif"
        elif is_link(source):
            reason = "Folder sumber adalah link/junction"
        elif not old and target.exists():
            reason = "Lokasi tujuan sudah digunakan"
        else:
            try:
                size, count = folder_details(source)
                if old:
                    old_size = sum(p.stat().st_size for p in walk_files(old))
            except Exception as exc:
                reason = str(exc)
        seen.add(pid)
        if reason:
            kind = "INVALID"
        result.append(FaceCandidate(pid, source, target, kind, size, old_size, count, reason))
    return sorted(result, key=lambda x: x.player_id)


def write_journal(folder: Path, data: dict) -> None:
    tmp = folder / "journal.tmp"
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    tmp.replace(folder / "journal.json")


def transaction_dir(library: Path) -> Path:
    return library.parent / ".pfm-transactions"


def pending_transactions(library: Path) -> list[Path]:
    root = transaction_dir(library)
    return sorted(p for p in root.iterdir() if p.is_dir()) if root.exists() else []


def _rollback(tx: Path, journal: dict) -> None:
    """Rollback one unfinished operation; never overwrite unrelated files."""
    source = Path(journal["source"])
    target = Path(journal["target"])
    old_existed = journal["old_existed"]
    mode = journal["mode"]
    backup = tx / "old"
    staged = tx / "incoming"
    failed = tx / "failed-new"
    if old_existed and not backup.exists() and journal.get("state") in ("old_moved", "installed"):
        raise RuntimeError("Backup versi lama tidak ditemukan. Pemulihan otomatis dihentikan agar data tidak hilang.")
    if failed.exists():
        raise RuntimeError("Ada failed-new yang belum diperiksa")

    # If backup exists, old target has already been moved out.
    if backup.exists():
        if target.exists():
            if mode == "move" and not source.exists():
                target.rename(source)
            else:
                target.rename(failed)
        if target.exists():
            raise RuntimeError("Tujuan belum kosong untuk pemulihan")
        backup.rename(target)
    elif not old_existed and target.exists():
        # For a newly added face, there was no prior folder.
        if mode == "move" and not source.exists():
            target.rename(source)
        else:
            target.rename(failed)
    elif old_existed and not target.exists():
        raise RuntimeError("Backup dan folder lama tidak ditemukan; perlu pemulihan manual")

    if mode == "move" and staged.exists():
        if source.exists():
            raise RuntimeError("Sumber sudah ada; stage belum dapat dipulihkan")
        staged.rename(source)

    # Only delete transaction artifacts after successful rollback.
    shutil.rmtree(tx)


def recover_transactions(library: Path) -> list[str]:
    """Explicit recovery, called only after user confirmation."""
    output = []
    for tx in pending_transactions(library):
        journal_path = tx / "journal.json"
        if not journal_path.exists():
            output.append(f"{tx.name}: jurnal hilang; perlu pemeriksaan manual")
            continue
        try:
            journal = json.loads(journal_path.read_text(encoding="utf-8"))
            if Path(journal["target"]).parent.resolve() != library.resolve():
                raise ValueError("Jurnal menunjuk ke library berbeda")
            if journal.get("state") in ("verified", "completed"):
                target = Path(journal["target"])
                if not target.is_dir() or manifest(target) != journal["expected"]:
                    raise RuntimeError("Hasil belum terverifikasi; perlu pemeriksaan manual")
                shutil.rmtree(tx)
                output.append(f"{tx.name}: instalasi terverifikasi, dibersihkan")
            else:
                _rollback(tx, journal)
                output.append(f"{tx.name}: versi lama dipulihkan")
        except Exception as exc:
            output.append(f"{tx.name}: GAGAL dipulihkan — {exc}")
    return output


def _move_mode(candidate: FaceCandidate, library: Path, requested: bool) -> str:
    # Fast atomic same-volume rename ONLY from the sibling staging directory.
    if requested and candidate.source.parent.resolve() == library.parent.resolve():
        return "move"
    return "copy"


def apply_one(candidate: FaceCandidate, library: Path, *, move_staging: bool = False,
              fail_hook=None) -> OperationResult:
    """Atomic-per-ID install; transaction journal enables crash recovery."""
    if candidate.kind == "INVALID":
        return OperationResult(candidate.player_id, "SKIPPED", candidate.reason)
    if pending_transactions(library):
        raise RuntimeError("Ada transaksi tertunda. Pulihkan dahulu sebelum impor baru.")
    current, aliases = library_records(library)
    pid = candidate.player_id
    if pid in aliases:
        raise RuntimeError(f"ID {pid} ambigu dalam library")
    previous = current.get(pid)
    if (previous or library / str(pid)) != candidate.target:
        raise RuntimeError("Library berubah sejak preview. Refresh dan ulangi.")
    size, _ = folder_details(candidate.source)
    if size != candidate.size:
        raise RuntimeError("Ukuran sumber berubah sejak preview. Refresh dan ulangi.")
    mode = _move_mode(candidate, library, move_staging)
    if mode == "copy" and shutil.disk_usage(library).free < size + 16 * 1024 * 1024:
        raise RuntimeError("Ruang kosong tidak cukup untuk menyalin face baru")
    expected = manifest(candidate.source)
    txroot = transaction_dir(library)
    txroot.mkdir(exist_ok=True)
    tx = txroot / f"{pid}-{uuid.uuid4().hex}"
    tx.mkdir()
    state = {
        "id": pid, "source": str(candidate.source.resolve()),
        "target": str(candidate.target.resolve()),
        "old_existed": previous is not None, "mode": mode,
        "state": "created", "expected": expected,
    }
    write_journal(tx, state)
    incoming = tx / "incoming"
    backup = tx / "old"
    target = candidate.target
    verified = False
    try:
        if mode == "move":
            candidate.source.rename(incoming)
        else:
            shutil.copytree(candidate.source, incoming)
        if manifest(incoming) != expected:
            raise RuntimeError("SHA256 file staging tidak sama dengan sumber")
        state["state"] = "prepared"
        write_journal(tx, state)
        if fail_hook:
            fail_hook("prepared", pid)
        if previous is not None:
            previous.rename(backup)
        state["state"] = "old_moved"
        write_journal(tx, state)
        if fail_hook:
            fail_hook("old_moved", pid)
        incoming.rename(target)
        state["state"] = "installed"
        write_journal(tx, state)
        if fail_hook:
            fail_hook("installed", pid)
        if manifest(target) != expected:
            raise RuntimeError("SHA256 file terpasang tidak cocok")
        state["state"] = "verified"
        write_journal(tx, state)
        verified = True
    except Exception as exc:
        try:
            _rollback(tx, state)
        except Exception as restore_err:
            raise RuntimeError(
                f"ID {pid} gagal: {exc}. Pemulihan belum selesai: {restore_err}. "
                f"Periksa folder {tx}"
            ) from exc
        raise RuntimeError(f"ID {pid} gagal dan telah dipulihkan: {exc}") from exc
    finally:
        # Important: do not automatically roll back after verified/commit.
        pass

    if verified:
        try:
            shutil.rmtree(tx)
            return OperationResult(pid, "REPLACED" if previous else "NEW", "SHA256 cocok; backup lama dibersihkan")
        except Exception as exc:
            return OperationResult(pid, "WARNING", f"Terpasang dan terverifikasi; folder transaksi belum bersih: {tx} ({exc})")
    raise RuntimeError("Transaksi berakhir tanpa verifikasi")


def sider_root_status(sider_ini: Path) -> tuple[str, list[str]]:
    if not sider_ini.is_file():
        return "sider.ini tidak ditemukan", []
    lines = sider_ini.read_bytes().decode("latin-1").splitlines()
    roots = [re.search(r'^\s*cpk\.root\s*=\s*["\']?([^"\'\r\n]+)', s, re.I).group(1).strip()
             for s in lines if re.search(r'^\s*cpk\.root\s*=\s*["\']?([^"\'\r\n]+)', s, re.I)]
    lower = [p.replace("/", "\\").lower().rstrip("\\") for p in roots]
    faces = [i for i, r in enumerate(lower) if r.endswith(r"\livecpk\faces")]
    t99 = [i for i, r in enumerate(lower) if r.endswith(r"\livecpk\t99-facepack")]
    if len(faces) != 1:
        return "Root Faces tidak ditemukan secara unik di sider.ini", roots
    if t99 and min(t99) < faces[0]:
        return "PERINGATAN: T99-Facepack prioritas lebih tinggi daripada Faces", roots
    return "Faces sudah di atas T99-Facepack (atau T99-Facepack tidak terdaftar)", roots


def prioritize_faces(sider_ini: Path) -> str:
    """Only modifies sider.ini after explicit GUI confirmation, with backup."""
    raw = sider_ini.read_bytes()
    text = raw.decode("latin-1")
    lines = text.splitlines(keepends=True)
    pattern = re.compile(r'^\s*cpk\.root\s*=\s*["\']?([^"\'\r\n]+)', re.I)
    positions = []
    for i, line in enumerate(lines):
        m = pattern.match(line)
        if m:
            r = m.group(1).strip().replace("/", "\\").lower().rstrip("\\")
            positions.append((i, r))
    faces = [i for i, r in positions if r.endswith(r"\livecpk\faces")]
    t99 = [i for i, r in positions if r.endswith(r"\livecpk\t99-facepack")]
    if len(faces) != 1 or len(t99) != 1:
        raise RuntimeError("Root Faces atau T99-Facepack tidak unik. Edit manual.")
    if faces[0] < t99[0]:
        return "Prioritas Faces sudah benar."
    line = lines.pop(faces[0])
    t99pos = next(i for i, x in enumerate(lines) if pattern.match(x) and
                  pattern.match(x).group(1).strip().replace("/", "\\").lower().rstrip("\\").endswith(r"\livecpk\t99-facepack"))
    lines.insert(t99pos, line)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = sider_ini.with_name(sider_ini.name + f".pfm-{stamp}.bak")
    if backup.exists():
        raise FileExistsError(f"Backup sudah ada: {backup}")
    shutil.copy2(sider_ini, backup)
    sider_ini.write_bytes("".join(lines).encode("latin-1"))
    return f"Faces diprioritaskan. Backup: {backup}"
