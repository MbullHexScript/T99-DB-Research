# PES Face Manager v1.0 — Windows / PES 2021 T99

Pengelola face LiveCPK untuk satu atau banyak Player ID. Dibuat untuk struktur PES 2021 `Asset/model/character/face/real/<PlayerID>/`.

## Instalasi (satu langkah)

1. Tutup **PES 2021**, **Sider**, dan Face Manager lama.
2. Ekstrak ZIP ini ke folder biasa.
3. Klik dua kali **`INSTALL_WINDOWS.cmd`**; ini memasang `main.py` dan `face_engine.py` ke `D:\Games-kuyhAa\T99-Research\tools\pes_face_manager`, membuat backup kode yang lama, lalu membuka aplikasi. Alternatif: jalankan `powershell -ExecutionPolicy Bypass -File .\install.ps1` dari direktori ini.
4. Untuk penggunaan berikutnya, buka `D:\Games-kuyhAa\T99-Research\tools\pes_face_manager\START_PES_FACE_MANAGER.cmd`.

Membutuhkan Python 3.10+ dan PySide6. Bila belum ada: `python -m pip install PySide6` (pengguna sebelumnya sudah memasangnya).

## Pemakaian

1. Library default: `D:\Games-kuyhAa\eFootball PES 2021\sider\livecpk\Faces\asset\model\character\face\real`.
2. Drag **folder ID** seperti `237566`, atau folder yang berisi banyak folder ID, ke tabel/kotak drop. Atau tekan **Pilih Folder untuk Import**.
3. Aplikasi menampilkan ID, nama (jika ada dalam T99), status `REPLACE`/`NEW`, ukuran lama/baru, dan paket yang ditahan.
4. Pilih ID yang ingin diproses, kemudian **Lanjutkan Update** dan konfirmasi.
5. **Mode Copy (default)** tidak menghapus sumber; sementara **Mode Move cepat** hanya bekerja untuk ID yang berada **langsung** di folder `face` sebagai sibling `real`. Mode Move akan menghilangkan folder ID di staging setelah pemasangan sukses.
6. Untuk batch besar (50 ID atau lebih), ketik `GANTI` pada konfirmasi akhir.

## Integrasi Sider

- Jika peringatan **T99-Facepack lebih tinggi daripada Faces** muncul, gunakan tombol **Prioritaskan Faces di Sider**, saat PES dan Sider tertutup.
- Tombol ini menyimpan backup `sider.ini.pfm-*.bak`, lalu memindahkan baris LiveCPK `Faces` tepat sebelum `T99-Facepack`. Fitur ini TIDAK dijalankan otomatis.
- Jika user mengelola folder LiveCPK lain yang lebih tinggi, file yang berbenturan tetap mungkin diprioritaskan oleh root lain. Periksa mod-mod lain bila wajah tidak berubah di dalam game.

## Pengamanan

- Cek struktur `#Win/face.fpk` dan `#Win/face.fpkd` dan file kosong.
- Tolak folder symbolic link / junction.
- Ganti seluruh folder ID — bukan overwrite per file — untuk mencegah tekstur lama tertinggal.
- SHA256 sumber, staging, dan tujuan diverifikasi. Backup versi lama dihapus **setelah** verifikasi sukses, agar storage tidak menumpuk. Bila ingin menyimpan versi lama secara permanen, backup secara manual sebelum impor.
- Setiap ID menggunakan transaksi independen dan jurnal di folder **`.pfm-transactions`** (sibling dari `real`). Jika aplikasi mati mendadak, buka lagi aplikasi dan konfirmasi pemulihan. **Jangan hapus `.pfm-transactions` secara manual.**
- Batch **bukan transaksi all-or-nothing**: face yang berhasil diproses sebelum kegagalan berikutnya tetap terpasang. Kegagalan ID tertentu memicu rollback ID itu, dan sisa batch dapat diproses ulang.
- Mode Move dan operasi file hanya didukung pada volume lokal biasa. Jangan jalankan dua instance bersamaan. Jangan jalankan PES/Sider saat memodifikasi library.

## Batasan

- Drag ZIP/RAR/7Z langsung tidak didukung; ekstrak dahulu.
- Nama pemain diambil dari `Player.bin` T99 saat tersedia; ID tak dikenal tidak otomatis berarti face tidak cocok.
- Tidak ada preview wajah 3D.
- Pengujian otomatis menguji operasi file pada folder sintetis, belum menguji mod secara visual di game atau GUI pada Windows milik pengguna.

## Tes & build .exe opsional

`python -m unittest discover -s tests -v` dijalankan dari folder hasil ekstraksi (pengujian menggunakan Python standar).

Setelah instalasi, untuk membuat Windows EXE, pasang `python -m pip install pyinstaller`, lalu jalankan `powershell -ExecutionPolicy Bypass -File .\build_exe.ps1`. Hasilnya di `tools\pes_face_manager\dist\PES-Face-Manager.exe`.
