import tempfile
import unittest
from pathlib import Path
import sys
import struct
import zlib
import json

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import face_engine as eng


class FaceManagerEngineTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.face = root / "Asset/model/character/face"
        self.library = self.face / "real"
        self.library.mkdir(parents=True)
        self.external = root / "downloads"
        self.external.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def make_face(self, parent, pid, version, extra=False):
        folder = parent / str(pid)
        (folder / "#Win").mkdir(parents=True)
        (folder / "#Win/face.fpk").write_bytes(b"fpk-" + version.encode())
        (folder / "#Win/face.fpkd").write_bytes(b"fpkd-" + version.encode())
        if extra:
            (folder / "sourceimages/#windx11").mkdir(parents=True)
            (folder / "sourceimages/#windx11/face_nrm.ftex").write_bytes(version.encode())
        return folder

    def test_replace_from_staging_fast_move(self):
        old = self.make_face(self.library, 557, "old", extra=True)
        new = self.make_face(self.face, 557, "new")
        plans = eng.plan_import([new], self.library)
        self.assertEqual(plans[0].kind, "REPLACE")
        out = eng.apply_one(plans[0], self.library, move_staging=True)
        self.assertEqual(out.status, "REPLACED")
        self.assertFalse(new.exists())
        self.assertEqual((old / "#Win/face.fpk").read_bytes(), b"fpk-new")
        self.assertFalse((old / "sourceimages").exists())  # no old texture leftovers
        self.assertEqual(eng.pending_transactions(self.library), [])

    def test_new_copy_does_not_delete_source(self):
        new = self.make_face(self.external, 725, "new", extra=True)
        plan = eng.plan_import([new], self.library)[0]
        self.assertEqual(plan.kind, "NEW")
        out = eng.apply_one(plan, self.library)
        self.assertEqual(out.status, "NEW")
        self.assertTrue(new.is_dir())
        self.assertEqual(eng.manifest(new), eng.manifest(self.library / "725"))

    def test_fail_after_install_restores_old_and_source_move(self):
        old = self.make_face(self.library, 557, "old", extra=True)
        before = eng.manifest(old)
        new = self.make_face(self.face, 557, "new")
        plan = eng.plan_import([new], self.library)[0]
        def crash(stage, pid):
            if stage == "installed":
                raise RuntimeError("simulated failure")
        with self.assertRaisesRegex(RuntimeError, "telah dipulihkan"):
            eng.apply_one(plan, self.library, move_staging=True, fail_hook=crash)
        self.assertEqual(eng.manifest(old), before)
        self.assertTrue(new.exists())
        self.assertEqual(eng.pending_transactions(self.library), [])

    def test_fail_after_old_moved_restores_old_copy(self):
        old = self.make_face(self.library, 557, "old")
        before = eng.manifest(old)
        new = self.make_face(self.external, 557, "new")
        plan = eng.plan_import([new], self.library)[0]
        def crash(stage, pid):
            if stage == "old_moved":
                raise RuntimeError("simulated failure")
        with self.assertRaisesRegex(RuntimeError, "telah dipulihkan"):
            eng.apply_one(plan, self.library, fail_hook=crash)
        self.assertEqual(eng.manifest(old), before)
        self.assertTrue(new.exists())
        self.assertFalse(eng.pending_transactions(self.library))

    def test_invalid_zero_tmp(self):
        new = self.make_face(self.external, 1, "new")
        (new / "temporary.tmp").touch()
        plan = eng.plan_import([new], self.library)[0]
        self.assertEqual(plan.kind, "INVALID")
        self.assertIn("kosong", plan.reason)

    def test_batch_preview_classification(self):
        self.make_face(self.library, 557, "old")
        self.make_face(self.external, 557, "new")
        self.make_face(self.external, 725, "new")
        plans = eng.plan_import([self.external], self.library)
        self.assertEqual([p.kind for p in plans], ["REPLACE", "NEW"])

    def test_explicit_crash_recovery(self):
        old = self.make_face(self.library, 557, "old")
        before = eng.manifest(old)
        tx = eng.transaction_dir(self.library) / "557-test"
        tx.mkdir(parents=True)
        new = self.make_face(self.external, 557, "new")
        (self.library / "557").rename(tx / "old")
        (tx / "incoming").mkdir()
        state = {"id": 557, "source": str(new), "target": str(old), "mode": "copy",
                 "state": "old_moved", "old_existed": True, "expected": eng.manifest(new)}
        eng.write_journal(tx, state)
        logs = eng.recover_transactions(self.library)
        self.assertTrue(any("dipulihkan" in item for item in logs))
        self.assertEqual(eng.manifest(old), before)
        self.assertFalse(eng.pending_transactions(self.library))

    def test_wesys_minimal_player_record(self):
        player = bytearray(312)
        struct.pack_into("<I", player, 8, 114022)
        player[251:251 + len(b"Caoimhin Kelleher")] = b"Caoimhin Kelleher"
        raw = bytes(player)
        compressed = zlib.compress(raw)
        content = b"\xff\x10\x81WESYS" + struct.pack("<II", len(compressed), len(raw)) + compressed
        path = Path(self.temp.name) / "Player.bin"
        path.write_bytes(content)
        self.assertEqual(eng.load_names(path), {114022: "Caoimhin Kelleher"})

    def test_sider_order_repaired_with_backup(self):
        ini = Path(self.temp.name) / "sider.ini"
        ini.write_bytes(b'cpk.root = ".\\livecpk\\T99-Facepack"\r\ncpk.root = ".\\livecpk\\Faces"\r\ncpk.root = ".\\livecpk\\GBK-Native-Test"\r\n')
        self.assertTrue(eng.sider_root_status(ini)[0].startswith("PERINGATAN"))
        eng.prioritize_faces(ini)
        self.assertTrue(eng.sider_root_status(ini)[0].startswith("Faces sudah"))
        self.assertEqual(len(list(ini.parent.glob("sider.ini.pfm-*.bak"))), 1)
        self.assertTrue(ini.read_bytes().endswith(b'cpk.root = ".\\livecpk\\GBK-Native-Test"\r\n'))


if __name__ == "__main__":
    unittest.main()
