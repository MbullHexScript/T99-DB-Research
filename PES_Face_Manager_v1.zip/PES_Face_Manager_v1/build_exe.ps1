$ErrorActionPreference = 'Stop'
$project = "D:\Games-kuyhAa\T99-Research\tools\pes_face_manager"
if (!(Test-Path -LiteralPath (Join-Path $project 'main.py'))) { throw 'Pasang aplikasi terlebih dahulu.' }
& python -m PyInstaller --version
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller belum terpasang. Jalankan: python -m pip install pyinstaller' }
Push-Location $project
try {
    & python -m PyInstaller --clean --noconfirm --onefile --windowed --name PES-Face-Manager main.py
    if ($LASTEXITCODE -ne 0) { throw 'Build gagal' }
    Write-Host "Executable: $project\dist\PES-Face-Manager.exe" -ForegroundColor Green
} finally { Pop-Location }
